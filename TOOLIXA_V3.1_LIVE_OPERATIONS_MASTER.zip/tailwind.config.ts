import type {Config} from 'tailwindcss';
export default {content:['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}'],theme:{extend:{fontFamily:{sans:['-apple-system','BlinkMacSystemFont','SF Pro Display','Inter','Segoe UI','sans-serif']}}},plugins:[]} satisfies Config;
